For Software Derived Requirements using the DOGM display, please see "display.h"

For Software Derived Requirements using the Piezo Speaker, please see "speaker.h"

For Software Derived Requirements using the MMA8451 accelerometer, please see "accelerometer.h"

For Software Derived Requirements using the ESP8266 WiFi module, please see "esp.h"

Please also define CLOCK_SETUP=1